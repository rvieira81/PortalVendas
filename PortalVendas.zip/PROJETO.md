# Portal de Vendas

## Fase atual: 5 — Testes (aguardando a primeira compilação e execução na máquina do Prado)

As fases 1 a 4 e a documentação das fases 5 a 7 estão prontas. Falta compilar, rodar os testes e homologar com as credenciais de teste.

## Escopo do MVP
Loja virtual de um vendedor: vitrine, carrinho, cadastro com CPF, endereço por CEP, frete em tempo real por peso e medidas (Melhor Envio), pagamento por Pix, cartão e boleto (Mercado Pago) e painel administrativo com 2FA.

## Stack decidida
- C# / .NET 10 LTS, ASP.NET Core MVC (Razor), Bootstrap 5.3
- SQL Server 2019+ com scripts versionados (`db/`)
- EF Core 10 (só mapeamento), Serilog, xUnit + SQLite
- Mercado Pago (API v1/payments + Card Payment Brick), Melhor Envio, ViaCEP
- IIS 10 em servidor Windows próprio

## Decisões tomadas (ADRs em docs/adr)
- 001 Monólito modular em 4 camadas
- 002 .NET 10 LTS (o 8 sai de suporte em nov/2026)
- 003 Esquema por scripts SQL versionados, não migrations
- 004 Autenticação por cookie com tabela própria + TOTP no admin
- 005 Mercado Pago com tokenização no navegador (PCI SAQ A)
- 006 Frete pelo Melhor Envio com contingência por faixa de CEP
- 007 Job de expiração/conciliação dentro do processo do IIS (AlwaysRunning)

## Entregáveis
| Fase | Entregável | Situação |
|---|---|---|
| 1 Requisitos | docs/01-requisitos.md | Aprovado |
| 2 Arquitetura | docs/02-arquitetura.md + 7 ADRs | Pronto |
| 3 Banco | docs/03-banco.md, db/migrations/V001, db/seed/S001, db/deploy-db.ps1 | Pronto |
| 4 Desenvolvimento | src/ (4 projetos), todos os RF "Must" e "Should" | Pronto, **não compilado ainda** |
| 5 Testes | tests/ (97 casos), docs/05-testes.md | Escrito, **não executado ainda** |
| 6 Implantação | deploy/*.ps1, web.config, CI, docs/06-implantacao.md | Pronto |
| 7 Entrega | README.md, docs/07-manual.md | Pronto |

## Pendências / riscos abertos
- **Compilação:** o código foi escrito sem SDK disponível (só verificação de sintaxe). Esperar ajustes pontuais no primeiro `dotnet build` — mandar a saída de erros para corrigir.
- **Credenciais de teste** do Mercado Pago e token do sandbox do Melhor Envio para o roteiro manual (docs/05-testes.md, seção 4).
- **Textos legais** (termos e privacidade) são modelos: revisão jurídica antes do go-live.
- **Nota fiscal** fora do MVP: vendas exigem emissão de NF-e por fora até a integração (backlog).
- Domínio, certificado HTTPS e conta SMTP de produção a definir.

## Backlog pós-MVP
1. Emissão de NF-e (integração com emissor: eNotas, Focus NFe, NFE.io)
2. Geração de etiqueta do Melhor Envio pelo painel (RF22) e rastreio automático
3. Cupons de desconto (RF21) — o pedido já tem a coluna `Desconto`
4. Variações de produto (tamanho/cor) com estoque por variação
5. Avaliações de produtos
6. Login social (Google/Apple)
7. QR Code na tela de configuração do 2FA e proteção contra reuso do mesmo código TOTP
8. Full-Text Search do SQL Server quando o catálogo passar de ~100 mil itens
9. Cache de saída na vitrine e CDN para imagens
10. Script de retenção LGPD para anonimizar endereços de pedidos com mais de 5 anos

## Próximo passo
Prado: `dotnet build` e `dotnet test` em `C:\SRC\PortalVendas`; enviar os erros (se houver) para correção. Depois, roteiro manual em homologação com credenciais de teste.
